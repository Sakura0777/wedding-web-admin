/** @format */

module.exports = {
  publicPath: "./",
  lintOnSave: false,
  productionSourceMap: false,
  transpileDependencies: [/\bvue-awesome\b/],
};
