import Main from "@/layout/main/index.vue";
import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

export const routes = [
  {
    path: "/",
    redirect: "customerPool",
    meta: {
      hidden: true,
    },
  },
  {
    path: "/login",
    name: "login",
    meta: {
      title: "登录",
      hidden: true,
    },
    component: () =>
      import(/* webpackChunkName: "login" */ "../views/login/index.vue"),
  },
  {
    path: "/customerPool",
    component: Main,
    redirect: "/customerPool/publicCustomerList",
    meta: {
      title: "客户池",
      icon: "restroom",
      quick: true,
    },
    children: [],
  },
];

const router = new VueRouter({
  routes,
});

export default router;
